<?php
$title = '';
$slug = '';
$state = '';
$city = '';
$address = '';
$home_type = '';
$room_type = '';
$bhk = '';
$project_status = '';
$property = '';
$overview = '';
$specification = '';
$seo_title = '';
$seo_keyword = '';
$seo_desc = '';
$eid ='';

$cdate = date('Y-m-d H:i:s');

if(isset($_POST['submit'])) {

    $title = trim($_POST['title']);
    $title = mysqli_real_escape_string($sql,$title);

    $slug = trim($_POST['slug']);
    $slug = mysqli_real_escape_string($sql,$slug);

    $state = trim($_POST['state']);
    $state = mysqli_real_escape_string($sql,$state);

    $city = trim($_POST['city']);
    $city = mysqli_real_escape_string($sql,$city);

    $address = trim($_POST['address']);
    $address = mysqli_real_escape_string($sql,$address);

    $home_type = trim($_POST['home_type']);
    $home_type = mysqli_real_escape_string($sql,$home_type);

    $room_type = trim($_POST['room_type']);
    $room_type = mysqli_real_escape_string($sql,$room_type);

    $bhk = trim($_POST['bhk']);
    $bhk = mysqli_real_escape_string($sql,$bhk);

    $project_status = trim($_POST['project_status']);
    $project_status = mysqli_real_escape_string($sql,$project_status);

    $overview = trim($_POST['overview']);
    $overview = mysqli_real_escape_string($sql, $overview);

    $specification = trim($_POST['specification']);
    $specification = mysqli_real_escape_string($sql, $specification);

    $property = trim($_POST['property']);
    $property = mysqli_real_escape_string($sql,$property);

    $seo_title = trim($_POST['seo_title']);
    $seo_title = mysqli_real_escape_string($sql,$seo_title);

    $seo_keyword = trim($_POST['seo_key']);
    $seo_keyword = mysqli_real_escape_string($sql,$seo_keyword);

    $seo_desc = trim($_POST['seo_desc']);
    $seo_desc = mysqli_real_escape_string($sql,$seo_desc);

    $eid = trim($_POST['eid']);
    $eid = mysqli_real_escape_string($sql, $eid);



    /*******************************Insert & Update**************************************/


    if($eid == ''){

        mysqli_query($sql,"INSERT INTO `addproperty` (`title`,`slug`,`state`,`city`,`address`,`h_type`,`r_type`,`bhk`,`project_status`,`property_by`,`overview`,`specification`,`seo_title`,`seo_keyword`,`seo_desc`,`created_date`,`created_by`) VALUES ('$title','$slug','$state','$city','$address','$home_type','$room_type','$bhk','$project_status','$property','$overview','$specification','$seo_title','$seo_keyword','$seo_desc','$cdate','1')");
        
        echo '<script type="text/javascript">window.location.href="addProperties.php?s=1"</script>';
    }

    else{

        mysqli_query($sql,"UPDATE `addproperty` SET `title`='$title',`slug`='$slug',`state`='$state',`city`='$city',`address`='$address',`h_type`='$home_type',`r_type`='$room_type',`bhk`='$bhk',`project_status`='$project_status',`property_by`='$property',`overview`='$overview',`specification`='$specification',`seo_title`='$seo_title',`seo_keyword`='$seo_keyword',`seo_desc`='$seo_desc',`updated_by`='1',`updated_date`='$cdate' WHERE id = '$eid'");
        echo '<script type="text/javascript">window.location.href="addProperties.php?u=1"</script>';            
    }


        /***********************************  Json*********************************/  


    $query_json = mysqli_query($sql, "SELECT * FROM `addproperty` WHERE `deleted` != '1'");

    $array_data = array();
 
    while($getdata_json = mysqli_fetch_object($query_json)){

        $master_data = array(
                                'title'  => $getdata_json->title,
                                'slug'   => $getdata_json->slug,
                                'state'  => $getdata_json->state,
                                'city' => $getdata_json->city,
                                'address'  => $getdata_json->address,
                                'home_type'  => $getdata_json->h_type,
                                'room_type'    => $getdata_json->r_type,
                                'bhk' => $getdata_json->bhk,
                                'project_status' => $getdata_json->project_status,
                                'property_by'  => $getdata_json->property_by,
                                'overview' => $getdata_json->overview,
                                'specification' => $getdata_json->specification,
                                'seo_title'    => $getdata_json->seo_title,
                                'seo_keyword'  => $getdata_json->seo_keyword,
                                'seo_desc'    => $getdata_json->seo_desc,
                             );
        $array_data[] = $master_data;

        $final_data = json_encode($array_data);

            if (!file_exists('../json/addproperty')) {
                mkdir('../json/addproperty', 0777, true);
            }

            file_put_contents('../json/addproperty/addproperty.json', $final_data);
        }

    }

if(isset($_GET['s'])) {

    $alertMessage = '<div class="alert alert-success mt-2 fadediv" role="alert">Data Inserted Successfully</div>';

}
if(isset($_GET['u'])){

    $alertMessage = '<div class="alert alert-success mt-2 fadediv" role="alert">Data updated Successfully</div>';

}





     /*********************************  Edit ***************************************/  

if(isset($_GET['eid'])) {

    $eid = trim($_GET['eid']);    
    $eid = mysqli_real_escape_string($sql, $eid);
    
    $selectdata = mysqli_query($sql, "SELECT * FROM `addproperty` WHERE `id` = '$eid'");
    
    $getdata = mysqli_fetch_object($selectdata);
    
    $title = $getdata->title;
    $slug = $getdata->slug;
    $state = $getdata->state;
    $city = $getdata->city;
    $address = $getdata->address;
    $h_type = $getdata->h_type;
    $r_type = $getdata->r_type;
    $bhk = $getdata->bhk;
    $project_status = $getdata->project_status;
    $property_by = $getdata->property_by;
    $overview = $getdata->overview;
    $specification = $getdata->specification;
    $seo_title = $getdata->seo_title;
    $seo_keyword = $getdata->seo_keyword;
    $seo_desc = $getdata->seo_desc;

    $eid = $getdata->id;
}


    /***********************************Functions***************************************/

   
    function states($sql, $selected) {

        $query2 = mysqli_query($sql, "SELECT * FROM `awt_states` ");
    
        while($listdata = mysqli_fetch_object($query2)) {
    
            echo '<option value="'.$listdata->id.'"';
            if($listdata->id == $selected) {echo ' selected="selected" ';}
            echo '>'.$listdata->name.'</option>';
    
        }
    
    }

    function city($sql, $selected) {

        $query3 = mysqli_query($sql, "SELECT * FROM `city_master` ");
    
        while($listdata = mysqli_fetch_object($query3)) {
    
            echo '<option value="'.$listdata->id.'"';
            if($listdata->id == $selected) {echo ' selected="selected" ';}
            echo '>'.$listdata->city.'</option>';
    
        }
    
    }

    function home($sql, $home) {

        $query4 = mysqli_query($sql, "SELECT * FROM `home_master` ");
    
        while($listdata = mysqli_fetch_object($query4)) {
    
            echo '<option value="'.$listdata->id.'"';
            if($listdata->id == $selected) {echo ' selected="selected" ';}
            echo '>'.$listdata->home.'</option>';
    
        }
    
    }

    function room($sql, $room) {

        $query5 = mysqli_query($sql, "SELECT * FROM `room_master` ");
    
        while($listdata = mysqli_fetch_object($query5)) {
    
            echo '<option value="'.$listdata->id.'"';
            if($listdata->id == $selected) {echo ' selected="selected" ';}
            echo '>'.$listdata->room.'</option>';
    
        }
    
    }

    function bhk($sql, $bhk) {

        $query7 = mysqli_query($sql, "SELECT * FROM `bhk_master` ");
    
        while($listdata = mysqli_fetch_object($query7)) {
    
            echo '<option value="'.$listdata->id.'"';
            if($listdata->id == $selected) {echo ' selected="selected" ';}
            echo '>'.$listdata->bhk.'</option>';
    
        }
    
    }

    function vendor($sql, $vendor) {

        $query6 = mysqli_query($sql, "SELECT * FROM `vendor_master` ");
    
        while($listdata = mysqli_fetch_object($query6)) {
    
            echo '<option value="'.$listdata->id.'"';
            if($listdata->id == $selected) {echo ' selected="selected" ';}
            echo '>'.$listdata->name.'</option>';
    
        }
    
    }



    /***************************  Delete **************************/ 


if(isset($_GET['did'])){
    $did = trim($_GET['did']);
    $did = mysqli_real_escape_string($sql,$did);

    mysqli_query($sql,"UPDATE `addproperty` SET `deleted`='1',`updated_date`='$cdate',`updated_by`='1' WHERE `id`='$did'");

    echo '<script type="text/javascript">window.location.href="addProperties.php?d=1"</script>';
}

if(isset($_GET['d'])){

    $alertMessage = '<div class="alert alert-success mt-2 fadediv" role="alert">Data Deleted Successfully</div>';
}


    /********************************  Query *********************************/ 

   
 $query = mysqli_query($sql,"SELECT a.*, r.room, v.name 
                        from `addproperty` as a 
                        left Join `room_master` as r on r.id = a.r_type 
                        left Join `vendor_master` as v on v.id = a.property_by 
                        where a.deleted != 1");


                        
$count = mysqli_num_rows($query);



    


?>