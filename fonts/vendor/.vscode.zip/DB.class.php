<?php

$sql= mysqli_connect("localhost", "project3_staybindass", "Ckx[e&t1az5J", "project3_staybindass");

?>