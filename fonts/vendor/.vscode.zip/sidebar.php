<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->

    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
        <div class="sidebar-brand-icon rotate-n-15"> </div>
        <img class="sidebar-brand-text mx-3" src="img/logo.png" width="95%">
    </a>


    <!-- Divider -->

    <hr class="sidebar-divider my-0">


    <!-- Nav Item - Dashboard -->

    <li class="nav-item">
        <a class="nav-link" href="dashboard.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>


    <!-- Nav Item - Pages Collapse Menu -->


    <li class="nav-item">
        <a class="nav-link collapsed  " href="#" data-toggle="collapse" data-target="#collapseSite" aria-expanded="true"
            aria-controls="collapseTwo">
            <i class="fas fa-fw fa-cog"></i>
            <span>Site setting</span>
        </a>

        <div id="collapseSite" class="collapse" aria-labelledby="collapsePro" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item " href="general.php">General</a>
                <a class="collapse-item" href="master.php">Master</a>
                <a class="collapse-item" href="our_story.php">Our Story</a>
                <a class="collapse-item" href="listyourproperty.php">List Your Property</a>
                <!-- <a class="collapse-item" href="preferences.php">Preferences</a> -->
            </div>
        </div>
    </li>

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseBlog" aria-expanded="true"
            aria-controls="collapseTrasn">
            <i class="fa fa-users"></i>
            <span>Blog</span>
        </a>

        <div id="collapseBlog" class="collapse" aria-labelledby="collapseBlog" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="add_blog.php">Add Blog</a>
                <a class="collapse-item" href="blog_list.php">Blog List</a>
            </div>
        </div>
    </li>

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseMaster" aria-expanded="true"
            aria-controls="collapseTrasn">
            <i class="fa fa-users"></i>
            <span>Master</span>
        </a>

        <div id="collapseMaster" class="collapse" aria-labelledby="collapseMaster" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="city_mast.php">City Master</a>
                <a class="collapse-item" href="room_master.php">Room Master</a>
                <a class="collapse-item" href="home_master.php">Home Master</a>
                <a class="collapse-item" href="guest.php">Guest Master</a>
                <a class="collapse-item" href="bhk_master.php">BHK Master</a>
                <a class="collapse-item" href="vendor_listing.php">Vendor Master</a>
                <a class="collapse-item" href="destination_master.php">Destination Master</a>
                <a class="collapse-item" href="prop_highlight_master.php"> Property Highlight Master</a>
            </div>
        </div>
    </li>

    

    <li class="nav-item">
        <a class="nav-link" href="filters.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Filters</span></a>
    </li>


    <li class="nav-item">
        <a class="nav-link" href="manage_users.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Manage Users</span></a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="onlinepayment.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Online Payment</span></a>
    </li>



    <!-- <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseDocs" aria-expanded="true"
            aria-controls="collapseTrasn">
            <i class="fa fa-list"></i>
            <span>Document Verification</span>
        </a>

        <div id="collapseDocs" class="collapse" aria-labelledby="collapseDocs" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="disapprove_documents.php">Disapprove Documents</a>
            <a class="collapse-item" href="approve_documents.php">Approve Documents</a>
            </div>
        </div>
    </li> -->


     <li class="nav-item">
        <a class="nav-link" href="manage_listing.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Manage Listings</span></a>
    </li> 



   <!--  <li class="nav-item">
        <a class="nav-link" href="manage_experience.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Manage Experience</span></a>
    </li> -->


   <!--  <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseExpSetting"
            aria-expanded="true" aria-controls="collapseExpSetting">
            <i class="fa fa-list"></i>
            <span>Experience Settings</span>
        </a>
        <div id="collapseExpSetting" class="collapse" aria-labelledby="collapseExpSetting"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="experience_category.php">Experience Category</a>
                <a class="collapse-item" href="inclusion.php">Inclusion</a>
                <a class="collapse-item" href="exclusion.php">Exclusion</a>
            </div>
        </div>
    </li> -->


    <!-- <li class="nav-item">
        <a class="nav-link" href="manage_bookings.php">
            <i class="fas fa-fw fa-table"></i>
            <span> Manage Bookings</span></a>
    </li> -->


   <!--  <li class="nav-item">
        <a class="nav-link" href="payout_requests.php">
            <i class="fas fa-fw fa-table"></i>
            <span> Payout Requests</span></a>
    </li>-->


    <!-- <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePanalty"
            aria-expanded="true" aria-controls="collapsePanalty">
            <i class="fa fa-list"></i>
            <span>Penalty</span>
        </a>
        <div id="collapsePanalty" class="collapse" aria-labelledby="collapsePanalty" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="host_penalty.php">Host Penalty</a>
            </div>
        </div>
    </li> -->


    <!-- <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseListSetting"
            aria-expanded="true" aria-controls="collapseListSetting">
            <i class="fa fa-list"></i>
            <span>Listing Settings</span>
        </a>
        <div id="collapseListSetting" class="collapse" aria-labelledby="collapseListSetting"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="property_type.php">Property Type</a>
                <a class="collapse-item" href="space_type.php">Space Type</a>
                <a class="collapse-item" href="bed_type.php">Bed Type</a>
            </div>
        </div>
    </li> -->



    <!-- <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseAmenities"
            aria-expanded="true" aria-controls="collapseAmenities">
            <i class="fa fa-list"></i>
            <span>Manage Amenities</span>
        </a>
        <div id="collapseAmenities" class="collapse" aria-labelledby="collapseAmenities"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="all_amenities.php">All Amenities</a>
                <a class="collapse-item" href="amenity_type.php">Amenities Type</a>
            </div>
        </div>
    </li> -->


    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFacilities"
            aria-expanded="true" aria-controls="collapseFacilities">
            <i class="fa fa-list"></i>
            <span>Manage Facilities</span>
        </a>
        <div id="collapseFacilities" class="collapse" aria-labelledby="collapseFacilities"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="facilities_listing.php">Facilities</a>
                <a class="collapse-item" href="subFacilities.php">Sub Facilities</a>
            </div>
        </div>
    </li>

     

    <!-- <li class="nav-item">
        <a class="nav-link" href="user_review.php">
            <i class="fas fa-fw fa-table"></i>
            <span> User Reviews</span></a>
    </li> -->

<!-- 
    <li class="nav-item">
        <a class="nav-link" href="site_testimonial.php">
            <i class="fas fa-fw fa-table"></i>
            <span> Site Testimonials</span></a>
    </li> -->


   <!--  <li class="nav-item">
        <a class="nav-link" href="customer_message.php">
            <i class="fas fa-fw fa-table"></i>
             <span> Customer Messages</span></a>
    </li> -->


    <!-- <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseStats" aria-expanded="true"
            aria-controls="collapseStats">
            <i class="fa fa-list"></i>
            <span>Reports & Stats</span>
        </a>
        <div id="collapseStats" class="collapse" aria-labelledby="collapseStats" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="regi_book.php">Overview</a>
                <a class="collapse-item" href="humi_book.php">Booking Report</a>
                <a class="collapse-item" href="humi_book.php">Data Analysis</a>
            </div>
        </div>
    </li>-->



    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseHomeSetting"
            aria-expanded="true" aria-controls="collapseHomeSetting">
            <i class="fa fa-list"></i>
            <span>Home Page Settings</span>
        </a>
        <div id="collapseHomeSetting" class="collapse" aria-labelledby="collapseHomeSetting"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="bottombanner.php">Bottom Banners</a>
                <a class="collapse-item" href="static_page.php">Static Page Setting</a>
                <!-- <a class="collapse-item" href="starting_cities_management.php">Starting Cities Management</a> -->
            </div>
        </div>
    </li>



   <!--  <li class="nav-item">
        <a class="nav-link" href="manage_country.php">
            <i class="fas fa-fw fa-table"></i>
            <span> Manage Country</span></a>
    </li> -->


    <!-- <li class="nav-item">
        <a class="nav-link" href="manage_currency.php">
            <i class="fas fa-fw fa-table"></i>
            <span> Manage Currency</span></a>
    </li> -->


<!-- 
    <li class="nav-item">
        <a class="nav-link" href="manage_language.php">
            <i class="fas fa-fw fa-table"></i>
            <span> Manage Languages</span></a>
    </li> -->



  <!--   <li class="nav-item">
        <a class="nav-link" href="customer_message.php">
            <i class="fas fa-fw fa-table"></i>
            <span> Customer Messages</span></a>
    </li> -->



    <!-- <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseHomeFeeSetting"
            aria-expanded="true" aria-controls="collapseHomeFeeSetting">
            <i class="fa fa-list"></i>
            <span>Payment & Fee settings</span>
        </a>
        <div id="collapseHomeFeeSetting" class="collapse" aria-labelledby="collapseHomeFeeSetting"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="payment_method.php">Payment Methods</a>
                <a class="collapse-item" href="fees_&_tax_setting.php">Fees & Tax settings</a>
            </div>
        </div>
    </li> -->


    <!-- <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseEmail" aria-expanded="true"
            aria-controls="collapseEmail">
            <i class="fa fa-list"></i>
            <span>Manage Emails</span>
        </a>
        <div id="collapseEmail" class="collapse" aria-labelledby="collapseEmail" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="mail_setting.php">Email Settings</a>
                <a class="collapse-item" href="#.php">Email Templates</a>
            </div>
        </div>
    </li> -->



    <!-- Nav Item - Tables -->

    <!-- <li class="nav-item">
        <a class="nav-link" href="sms_setting.php">
            <i class="fas fa-fw fa-table"></i>
            <span> SMS Settings</span></a>
    </li> -->



    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLoginSetting"
            aria-expanded="true" aria-controls="collapseLoginSetting">
            <i class="fa fa-list"></i>
            <span>Social Settings</span>
        </a>
        <div id="collapseLoginSetting" class="collapse" aria-labelledby="collapseLoginSetting"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="social_media_links.php">Social Media Links Settings</a>
                <a class="collapse-item" href="social_login_api.php">Social Login API</a>
            </div>
        </div>
    </li> 

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFaq"
            aria-expanded="true" aria-controls="collapseFaq">
            <i class="fa fa-list"></i>
            <span>FAQ </span>
        </a>
        <div id="collapseFaq" class="collapse" aria-labelledby="collapseFaq"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="faqcat.php">FAQ Categeory</a>
                <a class="collapse-item" href="faqmaster.php">FAQ Master</a>
            </div>
        </div>
    </li>

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSetting"
            aria-expanded="true" aria-controls="collapseSetting">
            <i class="fa fa-list"></i>
            <span>Settings</span>
        </a>

        <div id="collapseSetting" class="collapse" aria-labelledby="collapseSetting" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="contactUs.php">Contact Us</a>
                <a class="collapse-item" href="changepassword.php">Change Password</a>
            </div>
        </div>
    </li>


    <!-- Divider -->

    <hr class="sidebar-divider d-none d-md-block">


    <!-- Sidebar Toggler (Sidebar) -->

    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>